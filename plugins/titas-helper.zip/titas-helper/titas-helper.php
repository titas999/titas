<?php
/*
Plugin Name: Titas Helper Plugin
Plugin URI: 
Description: 
Author: Titas
Author URI: https://anisuzzaman.me
Text Domain: titas
Domain Path: /languages/
Version: 1.0.0
*/

function titas_load_text_domain(){
    load_plugin_textdomain('titas',false,dirname(__FILE__)."/languages");
}

add_action('plugins_loaded','titas_load_text_domain');

function titas_register_my_cpts() {

    /**
     * Post Type: Services.
     */

    $labels = array(
        "name" => __( "Services", "titas" ),
        "singular_name" => __( "Service", "titas" ),
    );

    $args = array(
        "label" => __( "Services", "titas" ),
        "labels" => $labels,
        "description" => "",
        "public" => false,
        "publicly_queryable" => false,
        "show_ui" => true,
        "delete_with_user" => false,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => array( "slug" => "all-services", "with_front" => true ),
        "query_var" => true,
        "menu_position" => 5,
        "menu_icon" => "dashicons-menu",
        "supports" => array( "title", "editor", "thumbnail" ),
    );

    register_post_type( "service", $args );

    /**
     * Post Type: Portfolio.
     */

    $labels = array(
        "name" => __( "Portfolio", "titas" ),
        "singular_name" => __( "Portfolio", "titas" ),
    );

    $args = array(
        "label" => __( "Portfolio", "titas" ),
        "labels" => $labels,
        "description" => "",
        "public" => false,
        "publicly_queryable" => false,
        "show_ui" => true,
        "delete_with_user" => false,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => array( "slug" => "all-portfolio", "with_front" => true ),
        "query_var" => true,
        "menu_position" => 5,
        "menu_icon" => "dashicons-menu",
        "supports" => array( "title", "editor", "thumbnail" ),
    );

    register_post_type( "portfolio", $args );

    /**
     * Post Type: Testimonial.
     */

    $labels = array(
        "name" => __( "Testimonial", "titas" ),
        "singular_name" => __( "Testimonial", "titas" ),
    );

    $args = array(
        "label" => __( "Testimonial", "titas" ),
        "labels" => $labels,
        "description" => "",
        "public" => false,
        "publicly_queryable" => false,
        "show_ui" => true,
        "delete_with_user" => false,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => array( "slug" => "all-testimonial", "with_front" => true ),
        "query_var" => true,
        "menu_position" => 5,
        "menu_icon" => "dashicons-menu",
        "supports" => array( "title", "editor", "thumbnail" ),
    );

    register_post_type( "testimonial", $args );

}

add_action( 'init', 'titas_register_my_cpts' );



